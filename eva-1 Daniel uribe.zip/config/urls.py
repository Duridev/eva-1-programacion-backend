from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [

    path('', RedirectView.as_view(url='/login/', permanent=False), name='home_redirect'),

    path('', include('accounts.urls')),
]